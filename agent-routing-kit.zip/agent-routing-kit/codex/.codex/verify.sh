#!/usr/bin/env bash
set -euo pipefail

root="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
cd "$root"
git diff --check
git diff --cached --check

# Добавьте сюда команды тестов, линтера или сборки вашего проекта.
