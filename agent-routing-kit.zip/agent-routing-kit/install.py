#!/usr/bin/env python3
"""Install the bundled agent rules and profiles into one existing project."""

import argparse
import os
from pathlib import Path
import stat
import sys
import tempfile

BEGIN = b"<!-- agent-routing-kit:begin -->"
END = b"<!-- agent-routing-kit:end -->"
CLAUDE_PROFILES = ("worker-haiku.md", "reviewer-haiku.md")
CODEX_PROFILES = (
    "kit_analysis_worker.toml",
    "kit_content_worker.toml",
    "kit_deep_architect.toml",
    "kit_fast_explorer.toml",
    "kit_fast_worker.toml",
    "kit_implementation_worker.toml",
    "kit_strict_reviewer.toml",
)


def checked_path(root, relative):
    path = root
    for part in relative.split("/")[:-1]:
        path = path / part
        if path.is_symlink() or (path.exists() and not path.is_dir()):
            raise ValueError(f"Ожидалась обычная папка: {path}")
    path = root / relative
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise ValueError(f"Ожидался обычный файл: {path}")
    return path


def add_new_file(root, relative, data, changes):
    target = checked_path(root, relative)
    if not target.exists():
        changes.append((relative, data, None))
    elif target.read_bytes() != data:
        raise ValueError(f"Файл уже существует и отличается: {relative}. Сверьте его вручную.")


def make_plan(root, tool):
    source = Path(__file__).resolve().parent / tool
    claude = tool == "claude-code"
    folder, rules, profiles = (
        (".claude", "CLAUDE.md", CLAUDE_PROFILES)
        if claude else (".codex", "AGENTS.md", CODEX_PROFILES)
    )
    body = (source / rules).read_bytes()
    changes = []
    if claude:
        target = checked_path(root, rules)
        if not target.exists() or body.strip() not in target.read_bytes().replace(b"\r\n", b"\n"):
            relative = ".claude/rules/agent-routing-kit.md"
            add_new_file(root, relative, body, changes)
    else:
        if checked_path(root, "AGENTS.override.md").exists():
            raise ValueError("AGENTS.override.md имеет приоритет. Добавьте правила комплекта в него вручную.")
        target = checked_path(root, rules)
        existing = target.read_bytes() if target.exists() else None
        old = existing or b""
        marked = BEGIN + b"\n" + body.strip() + b"\n" + END
        normalized = old.replace(b"\r\n", b"\n")
        if BEGIN in normalized or END in normalized:
            if normalized.count(BEGIN) != 1 or normalized.count(END) != 1 or marked not in normalized:
                raise ValueError(f"В {rules} есть изменённый или неполный блок комплекта. Сверьте его вручную.")
        elif body.strip() not in normalized:
            merged = old + (b"\n\n" if old else b"") + marked + b"\n"
            changes.append((rules, merged, existing))

    for name in profiles:
        relative = f"{folder}/agents/{name}"
        add_new_file(root, relative, (source / relative).read_bytes(), changes)

    if not claude:
        relative = ".codex/verify.sh"
        if not checked_path(root, relative).exists():
            changes.append((relative, (source / relative).read_bytes(), None))
        else:
            print("Сохраняется имеющийся .codex/verify.sh.")
    return changes


def write_new(path, data, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
        temporary = Path(stream.name)
        try:
            stream.write(data)
            stream.flush()
            stream.close()
            temporary.chmod(mode)
            # Link atomically and fail if a competing writer created this file.
            os.link(temporary, path)
        finally:
            temporary.unlink()


def apply_plan(root, changes):
    # Create new files first. Update the rules last so they never refer to a half-installed set.
    changes = sorted(changes, key=lambda change: change[0] in ("AGENTS.md", ".claude/rules/agent-routing-kit.md"))
    added = []
    try:
        for relative, data, previous in changes:
            target = checked_path(root, relative)
            if previous is None:
                write_new(target, data, 0o755 if target.suffix == ".sh" else 0o644)
                added.append(target)
                continue
            if target.read_bytes() != previous:
                raise ValueError(f"Файл изменился после проверки плана: {relative}. Повторите установку.")
            backup = Path(tempfile.mkdtemp(prefix=".agent-routing-kit-backup-", dir=root)) / relative
            backup.write_bytes(previous)
            print(f"Резервная копия: {backup}")
            mode = stat.S_IMODE(target.stat().st_mode)
            with tempfile.NamedTemporaryFile(dir=root, delete=False) as stream:
                temporary = Path(stream.name)
                try:
                    stream.write(data)
                    stream.flush()
                    stream.close()
                    temporary.chmod(mode)
                    temporary.replace(target)
                finally:
                    if temporary.exists():
                        temporary.unlink()
    except (OSError, ValueError):
        for path in reversed(added):
            path.unlink()
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tool", required=True, choices=("codex", "claude-code"))
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--apply", action="store_true", help="Записать изменения из плана")
    args = parser.parse_args()
    try:
        root = args.project.expanduser()
        if root.is_symlink() or not root.is_dir():
            raise ValueError("Укажите путь к существующей папке проекта.")
        root = root.resolve(strict=True)
        if root in (root.parent, Path.home().resolve()):
            raise ValueError("Укажите корень проекта, отличный от домашней папки и корня диска.")
        changes = make_plan(root, args.tool)
        if not changes:
            print("Комплект уже установлен.")
            return 0
        print(f"Проект: {root} ({args.tool})")
        for relative, _, previous in changes:
            action = "Добавить правила в" if previous is not None else "Создать"
            print(f"{action} {relative}")
        if args.apply:
            apply_plan(root, changes)
            print("Установка завершена. Откройте новую сессию в этом проекте.")
        else:
            print("План проверен. Для установки добавьте --apply.")
        return 0
    except (OSError, ValueError) as exc:
        print(f"Установка остановлена: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
