#!/usr/bin/env bash
set -euo pipefail

cd "$(git rev-parse --show-toplevel)"
git diff --check
git diff --cached --check

# Добавьте команды своего проекта, например целевой тест или линтер.
