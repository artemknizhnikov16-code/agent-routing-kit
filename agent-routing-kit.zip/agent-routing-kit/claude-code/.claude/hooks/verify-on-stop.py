"""Run the starting checkout's project verification on Claude Code Stop."""

import json
from pathlib import Path
import subprocess
import sys


def main():
    event = json.load(sys.stdin)
    if event.get("hook_event_name") != "Stop" or event.get("stop_hook_active"):
        return 0

    project = Path(__file__).resolve().parents[2]
    verify = project / ".claude" / "verify.sh"
    if not verify.is_file():
        return 0

    prefix = subprocess.run(
        ["git", "rev-parse", "--show-prefix"], cwd=project, capture_output=True
    )
    if prefix.returncode != 0 or prefix.stdout.strip():
        return 0

    status = subprocess.run(
        ["git", "status", "--porcelain"], cwd=project, check=True, capture_output=True
    )
    if not status.stdout:
        return 0

    result = subprocess.run(
        ["bash", ".claude/verify.sh"],
        cwd=project,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        errors="replace",
    )
    if result.returncode == 0:
        return 0

    print(f"Проверка .claude/verify.sh завершилась с кодом {result.returncode}.", file=sys.stderr)
    print("\n".join(result.stdout.splitlines()[-30:]), file=sys.stderr)
    print("Исправь ошибки и повтори проверку вручную перед ответом.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
